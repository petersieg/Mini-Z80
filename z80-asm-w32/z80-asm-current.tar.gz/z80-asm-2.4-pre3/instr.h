/* INSTRUCTION TYPES FOR LEXICAL ANALYSIS (DURING ASSEMBLING) */

#ifndef __INSTR_H
#define __INSTR_H

#include "instr_token"
extern const struct seznam_type instruction[N_INSTRUCTIONS];

#endif
