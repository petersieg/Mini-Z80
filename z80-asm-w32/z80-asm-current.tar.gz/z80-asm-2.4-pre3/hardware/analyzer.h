#ifndef __ANALZER_H
#define __ANALZER_H

extern void send_pulse_to_analyzer(void);
extern unsigned reset_analyzer(char *filename);

#endif
