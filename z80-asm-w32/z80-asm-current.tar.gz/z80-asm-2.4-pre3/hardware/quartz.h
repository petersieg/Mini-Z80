#ifndef __QUARTZ_H
#define __QUARTZ_H

extern void clock_oscillator(void);
extern unsigned clock_frequency(void);

#endif
